---
name: board
description: >
  视觉风格 Skill。读取体验蓝图与现有设计规范，输出 3-4 套视觉风格方向，并在用户选定后沉淀结构化设计变量。
  仅在用户明确要求视觉风格、视觉方向、风格方案或设计变量时使用；不得在体验蓝图完成后自动触发。
  排除：设计策略报告（用 design-strategy）、交互方案（用 experience-blueprint）、页面规格（用 page-spec）。
---

# Board

这个 skill 负责把体验蓝图里的角色、场景和触点，转成可落地的视觉方向方案。

它的任务不是发明一套全新设计系统，而是在现有规范和当前产品语境内，整理出几套清晰可选的视觉方向，并把选定方案沉淀为可复用的设计变量。

## Step 0 · 运行入口

### Step 0.1 · 本 Skill 产物状态

执行本 Skill 前，只检查本 Skill 对应正式产物是否存在。

正式产物：
- `spark-output/board_output.md`
- `spark-output/context/board.json`

只允许检查文件是否存在；禁止读取产物正文、禁止解析 JSON 内容、禁止根据已有产物改变当前任务类型。

若任一正式产物存在，先输出以下状态提示，然后继续执行本 Skill 的入口规则：

```text
检测到本 Skill 已有正式产物（已产出）。
```

该提示只表示状态，不代表采取任何处理动作。

禁止：
- 读取产物正文
- 解析 JSON 内容
- 根据已有产物改变当前任务类型
- 根据已有产物执行下游
- 根据已有产物询问处理方式
- 根据已有产物推断用户意图

### Step 0.2 · 上游读取与模式判断

启动后按以下顺序读取：

1. 按当前 `SKILL.md` 的规则确认本 Skill 自身输入边界
2. 读取 `spark-output/context/experience-blueprint.json`
3. 读取 `spark-output/experience_blueprint.md`
4. 如需知识补充，从 `knowledge-wiki` 的 `knowledge/wiki/index.md` 按实际入口进入必要 README 或单一 raw，只读命中的设计规范、品牌约束或视觉准则章节；不得预设目录层级或遍历 raw

这是链路消费型 skill，默认承接 `spark-output/` 中的上游产物属于正式工作流。

降级规则：

- 只要有体验蓝图产出，就可以按链式模式执行
- 如果没有书面设计规范，要显式说明“以下方案基于当前蓝图和通用实践推导”
- 如果没有体验蓝图，则转为独立模式，向用户确认产品语境、目标用户和想要的调性

### Step 0.3 · 独立模式确认

没有完整上游时，先确认：

1. 产品或模块的语境
2. 目标用户
3. 期望的视觉气质
4. 是否已有品牌色、字体或组件约束

独立模式仍然输出 3-4 套方案，但必须把“哪些内容来自用户明确输入，哪些是推导”说清楚。

## 角色定义

Board 负责：

- 提炼视觉语境、用户感受和关键触点
- 在现有规范内推导 3-4 套方向方案
- 说明每套方案适合什么场景、为什么成立
- 在用户选定后输出结构化设计变量

Board 不负责：

- 重写交互方案
- 直接产出高保真页面稿
- 脱离现有规范自由发明 token
- 代替视觉设计师做最终定稿

## 核心映射规则

Board 不依赖外部情绪映射文件，固定使用以下轻量映射：

- 信任 / 稳定 / 专业：深蓝、蓝灰、中性灰，字重偏稳
- 高效 / 工具感 / 理性：石墨、冷灰、少量强调色，结构清晰
- 温和 / 陪伴 / 安心：浅绿、米白、柔和中性色，留白更充足
- 创新 / 探索 / 灵感：紫色、青色、珊瑚色，高对比点缀
- 活力 / 增长 / 推动：绿色、橙色、亮色强调，CTA 更突出

要求：

- 先看现有品牌或规范约束，再决定具体组合
- 方案之间必须有明显方向差异，但不能脱离产品场景
- 方案说明要覆盖：色彩、字体、组件气质、适用触点

## 执行流程

### Step 1：确认视觉约束

- 先确认是否存在现有规范、品牌色、字体或组件风格
- 有规范时，方案只能在既有边界内组合
- 无规范时，在输出开头明确标注该缺口

### Step 2：提炼触点与情绪

- 从体验蓝图中提炼关键触点、角色感受和场景差异
- 如果有多个角色，优先抓主角色和高频核心场景
- 不把所有情绪平均处理，要突出最核心的 1-2 个主导方向

### Step 3：输出 3-4 套方案

每套方案至少说明：

- 方案名
- 适用语境
- 关键词
- 主色 / 辅色 / 中性色方向
- 字体建议
- 组件气质
- 适合强化的触点

### Step 4：用户确认并写入结果

用户选定方案后，输出到：

- `spark-output/board_output.md`
- `spark-output/context/board.json`

输出规则补充：

- 如果宿主支持文件系统，先检查并创建 `spark-output/` 与 `spark-output/context/`，再写入产物

`board.json` 至少包含：

- `skill`
- `version`
- `generated_at`
- `project_name`
- `selected_scheme`
- `style_keywords[]`
- `color`
- `typography`
- `spacing`
- `radius`
- `component`

如果用户暂未选定，也可以先输出提案文档，但要明确标注“尚未最终确认方案”，不要把未确认方案写成最终 token。

## 输出要求

Markdown 提案至少包含：

- 当前视觉约束
- 关键触点与视觉目标
- 3-4 套方案对比
- 推荐方案与推荐理由
- 待确认项

JSON 要求：

- 只在方案确认后写最终版本
- 不输出空的设计变量对象
- 颜色、字体、间距和组件字段要成套出现

## Context JSON 写入

正式产物生成后，按固定结构写入 `spark-output/context/board.json`。

固定结构：

```json
{
  "skill": "board",
  "version": "1.0",
  "generated_at": "unknown",
  "project_name": "unknown",
  "artifact_md": "spark-output/board.md",
  "source_refs": [],
  "read_sections": [],
  "selected_scheme": {
    "scheme_id": "unknown",
    "scheme_name": "unknown",
    "selection_reason": "unknown"
  },
  "style_keywords": [],
  "color": {
    "primary": "unknown",
    "secondary": "unknown",
    "background": "unknown",
    "surface": "unknown",
    "text": "unknown",
    "semantic": {}
  },
  "typography": {
    "font_family": "unknown",
    "scale": [],
    "weight": []
  },
  "spacing": {
    "base": "unknown",
    "scale": []
  },
  "radius": {
    "base": "unknown",
    "scale": []
  },
  "component": {
    "button": {},
    "card": {},
    "input": {},
    "navigation": {},
    "feedback": {}
  },
  "open_questions": []
}
```

硬规则：

- 字段固定，不得新增、删除或改名。
- 只填入本 Skill 正式 Markdown 已产出的信息；缺失信息写 `unknown`、空数组，或进入 `open_questions[]`。
- 不得为了填满 JSON 编造信息。
- 只写最终选中方案和变量；未确认候选方案不得写成最终方案。
- `component` 只填当前产物明确给出的组件规则，不补设计系统。
- JSON 不复制 Markdown 全文。
- 写入失败不阻断完成，但应在输出中提示。

## Handoff · 固定下一步

固定输出：

```text
视觉情绪板已完成。当前没有固定下一步推荐。
你可以停在这里。
```

**硬规则：正式产物写入并校验通过后，必须执行 `node shared-workflow/generate-progress-preview.js`；失败仅告警，不得阻断 Handoff。**

## 边界

- 不照搬原始产品设计 skill 里的重型 HTML 生成链
- 不输出 marker、dashboard 或其他已暂缓执行的 chain 机制
- 不把“通用审美偏好”冒充为“现有设计规范”
- 不在没有用户确认时把候选方案写成最终方案
