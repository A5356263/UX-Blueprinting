---
name: product-analysis
description: >
  产品分析 Skill。对已有需求方向被否定、不成立或明确需要重构的场景做问题重构和轻量方案发散，输出 2-3 条可行方向。
  触发关键词：产品分析、问题重构、重新定义问题、需求方向不对、方向不成立、重述问题、打开方案空间、方案发散。
  不用于尚未形成方向的白纸探索（用 problem-framing），也不得仅因材料存在矛盾或不完整而自动触发。
  排除：正式需求定案（用 uxb）、设计策略（用 design-strategy）。
---

# Product Analysis

这个 skill 用于承接一种特定情况：

```text
已有方向、方案、PRD 或阶段性 UXB 判断
但当前方向不足以继续正式定案
需要先重定义问题，再打开 2-3 条替代方向
```

它不是 UXB 的默认主流程，也不是无条件脑暴工具，更不是白纸场景入口。

## Step 0 · 运行入口

### Step 0.1 · 本 Skill 产物状态

执行本 Skill 前，只检查本 Skill 对应正式产物是否存在。

正式产物：
- `spark-output/product_analysis.md`
- `spark-output/context/product-analysis.json`

只允许检查文件是否存在；禁止读取产物正文、禁止解析 JSON 内容、禁止根据已有产物改变当前任务类型。

若任一正式产物存在，先输出以下状态提示，然后继续执行本 Skill 的入口规则：

```text
检测到本 Skill 已有正式产物（已产出）。
```

该提示只表示状态，不代表采取任何处理动作。

禁止：
- 读取产物正文
- 解析 JSON 内容
- 根据已有产物改变当前任务类型
- 根据已有产物执行下游
- 根据已有产物询问处理方式
- 根据已有产物推断用户意图

### Step 0.2 · 来源模式

`product-analysis` 必须支持两种正式来源模式：

- `direct-input`
  - 用户直接带 PRD、方案、文档或口述问题进入
  - 当前不在 `uxb` 执行中
- `uxb-inflight`
  - 当前任务正在 `uxb` 中
  - 因方向不成立、用户要求重想或 UXB 判断需开方案空间而切入

### Step 0.3 · 上游读取

#### 模式 A：`direct-input`

读取顺序：

1. 当前对话中的问题背景、已有方向、失败点、约束
2. 用户明确提供的文件路径、PRD、文档
3. 如用户明确要求“基于已有产物继续”，再读取对应产物
4. 不默认扫描工作区历史产物

#### 模式 B：`uxb-inflight`

读取顺序：

1. 当前对话中的问题背景、当前争议点、用户新补充
2. 当前 `uxb` 已形成的阶段性结论
3. `spark-output/context/uxb.json`
4. `spark-output/uxb_output.md`
5. 如有必要，再读取原始 PRD / 文档

在该模式下，`uxb` 已确认的事实和约束属于有效输入，不重新丢弃。

### Step 0.4 · 进入门槛

`product-analysis` 不得因为“感觉一般”直接触发。正式执行前必须先判断，满足任一条件才允许进入：

1. 用户给的是方案，不是问题
2. 当前方案跳过了关键前提
3. 当前方案解决的是表象，不是真问题
4. 当前方案与业务约束冲突
5. 当前方案即使实现，也不足以达成成功标准

## 适用场景

适用于：

- 需求方向明显不成立
- 用户给的是方案，但还没证明真实问题
- 当前更需要重述问题，而不是继续蓝图分析
- 需要打开 2-3 条可行方案方向，再决定是否回到 UXB
- 当前正在 `uxb` 中，且已经判断现有方向需要纠偏

不适用于：

- 问题尚未成形、仍是白纸探索
- 已经可以直接进入 UXB 正式蓝图
- 单纯体验诊断
- 单纯知识问答
- 已经确认只需要做 facts / business / experience 产物

## 目标

先把问题重新定义清楚，再决定是否发散方案。

优先回答：

1. 真问题是什么
2. 当前方案为什么不够成立
3. 还有哪些替代方向值得看
4. 下一步是继续产品分析，还是回到 UXB

## 工作方式

### Step 1：判断是否真的需要产品分析

先用一句话判断：

- 当前更像白纸问题
- 当前更像方向重构问题
- 当前已经可以继续正式定案

只有命中“方向重构问题”时，继续后续步骤。

### Step 2：重定义问题

先回答：

- 谁真的有问题
- 现在怎么解决
- 为什么重要
- 什么算成功
- 当前方案跳过了什么前提
- 当前方案为什么不足以继续

要求：

- 区分已确认事实、推断、判断、缺口
- 不把旧方案直接重写成真问题
- 不提前进入页面或交互方案

### Step 3：给出方向选项

只给 2-3 条方向，不追求大规模创意发散。

每条方向至少说明：

- 解决什么问题
- 核心思路是什么
- 主要风险是什么
- 适用前提是什么

必须明确推荐 1 条方向，不允许只列备选。

### Step 4：建议下一步

只保留两类下一步：

1. 继续产品分析
2. 回到 UXB 做正式定案

其中：

- `继续产品分析` 只在推荐方向仍不稳定、关键前提未补齐时允许
- 默认推荐路径应是 `回到 UXB 做正式定案`

## 输出风格

- 大白话
- 先说判断
- 少术语
- 不默认跑完整 SCAMPER
- 不强制 Top 3 创意筛选

## 输出结构

输出到：

- `spark-output/product_analysis.md`
- `spark-output/context/product-analysis.json`

Markdown 固定结构：

```markdown
# 产品分析：{项目名}

## §0 关键判断
## §1 当前方向为什么不成立
## §2 真问题重定义
## §3 被跳过的关键前提
## §4 替代方向
## §5 推荐方向
## §6 下一步建议
## §7 不做什么
## §8 待确认问题
```

## Context JSON 写入

文档生成后，按固定结构写入 `spark-output/context/product-analysis.json`。

固定结构：

```json
{
  "skill": "product-analysis",
  "version": "1.0",
  "generated_at": "unknown",
  "project_name": "unknown",
  "artifact_md": "spark-output/product_analysis.md",
  "source_refs": [],
  "read_sections": [],
  "source_mode": "unknown",
  "key_judgments": [
    {
      "judgment": "unknown",
      "impact": "unknown",
      "recommended_approach": "unknown",
      "not_recommended": "unknown",
      "open_question": "unknown"
    }
  ],
  "input_summary": {
    "raw_request": "unknown",
    "confirmed_facts": [],
    "explicit_constraints": [],
    "missing_information": []
  },
  "current_direction_failure": {
    "direction": "unknown",
    "why_invalid": "unknown",
    "evidence": []
  },
  "reframed_problem": {
    "problem": "unknown",
    "root_cause": "unknown",
    "target_user": "unknown"
  },
  "skipped_premises": [
    {
      "premise": "unknown",
      "impact": "unknown"
    }
  ],
  "alternative_directions": [
    {
      "direction": "unknown",
      "core_idea": "unknown",
      "solves": "unknown",
      "risk": "unknown",
      "assumption": "unknown"
    }
  ],
  "recommended_direction": {
    "summary": "unknown",
    "reason": "unknown",
    "next_step": "unknown"
  },
  "next_step": "unknown",
  "not_to_do": [],
  "gaps": [
    {
      "question": "unknown",
      "impact": "unknown"
    }
  ]
}
```

硬规则：

- 字段固定，不得新增、删除或改名。
- 只填入本 Skill 正式 Markdown 已产出的信息；缺失信息写 `unknown`、空数组，或进入 `gaps[]`。
- 不得为了填满 JSON 编造信息。
- `source_mode` 只允许 `direct-input`、`uxb-inflight` 或 `unknown`。
- `current_direction_failure` 和 `reframed_problem` 必须同时保留。
- `skipped_premises[]` 不得并入 `gaps[]`。
- `recommended_direction` 必须是结构对象，不能只写标题。
- `next_step` 只允许 `continue-product-analysis`、`return-to-uxb` 或 `unknown`。
- JSON 不复制 Markdown 全文。

## Handoff · 固定下一步

本 Skill 完成后，只输出固定下一步推荐。

输出推荐前，只检查以下正式产物是否存在；若存在，只在“需求定案”后追加“（已产出）”。

- `spark-output/uxb_output.md`
- `spark-output/context/uxb.json`

禁止：
- 读取推荐项产物正文
- 根据产物存在改变推荐顺序
- 动态计算候选项
- 读取 shared-workflow/next-skill.md 生成候选项
- 读取 shared-workflow/skill-graph.json 生成候选项
- 直接执行下一步

固定输出：

```text
产品分析已完成。你可以继续：
1. 需求定案

你回复对应名称即可。
```

“（已产出）”只代表状态，不代表该项被选中或质量通过。

**硬规则：正式产物写入并校验通过后，必须执行 `node shared-workflow/generate-progress-preview.js`；失败仅告警，不得阻断 Handoff。**

## 边界

- 可以吸收问题聚焦、5 Why、轻量方案发散
- 不把完整脑暴框架强行跑满
- 不替用户做最终决策
- 不直接生成 UXB 正式产物
- 不作为白纸探索入口
- 不直接进入后续主链或正式蓝图
